<?php
define("BROWSER_TITLE","clubs");


define("ID_HEADING","id");
define("SHORTNAME_REMARK","max 4 Zeichen");

define("SHORTNAME_HEADING","Verein");

define("NAME_HEADING","Name");

define("CLUB_NO_HEADING","Nummer");

define("CLUB_URL_HEADING","URL");
define("CLUB_URL_REMARK","Link zur Homepage des Vereins");

define("REGION_HEADING","Bezirk");
define("MEM_LASTCHANGE_HEADING","Anspr.");
define("TEAM_LASTCHANGE_HEADING","Mannsch.");
define("GYM_LASTCHANGE_HEADING","Halle");
define("REF_LASTCHANGE_HEADING","Schiri");
?>