<?php
define("BROWSER_TITLE","clubs teams");
define("PAGE_TITLE","admin clubs teams");


define("CLUB_ID_HEADING","id");
define("LEAGUE_CHAR_HEADING","Buchstabe");
define("SHORTNAME_HEADING","Verein");

define("LEAGUE_ID_HEADING","Liga id");
define("LEAGUE_NAME_HEADING","Liga");
define("LEAGUE_TEAMS_HEADING","Anzahl Teams");

define("TRAINING_DAY_HEADING","Training Tag");
define("TRAINING_TIME_HEADING","Training Zeit");
define("PREF_GAME_DAY_HEADING","Bevorz. Spieltag");
define("PREF_GAME_TIME_HEADING","Bevorz. Spielzeit");
define("LASTNAME_HEADING","Verantwortlicher");
define("PHONE1_HEADING","Tel. (p)");
define("PHONE2_HEADING","Tel. (d)");
define("EMAIL_HEADING","E-Mail");

?>