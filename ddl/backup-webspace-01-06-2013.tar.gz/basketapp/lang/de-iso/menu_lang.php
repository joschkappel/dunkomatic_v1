<?php

define("LOGOUT","Logout");
define("ADMIN_HOME","Start");
define("MAIN_MENU","Menu");
define("USERNAME_TITLE","Benutzer");
define("PASSWORD_TITLE","Passwort");
define("LOGIN_TITLE","Anmelden");



/*
 * JK  language string table
 */

$strChangePwd = 'Passwort ändern';
$strMenuHelp = 'FAQ / Hilfe';
$strLogout = 'Beenden';
$strHome = 'Startseite';
// side bar menu 
$sMenuHeadAdmin = 'Arbeiten mit...';
$sMenuClubs = 'Vereinen';
$sMenuMembers = 'Ansprechpartnern';
$sMenuLeagues = 'Runden';
$sMenuSeason = 'Spielen';
$sMenuReferees = 'Schiedsrichtern';
$sMenuHeadConfig = 'Prüfung auf...';
$sMenuTeamChar = 'Buchstabenänderungen';
$sMenuDuplicates = 'Doppelbelegungen';
$sMenuRefCheck = 'Schiedsrichter Check';
$sMenuHeadSchemes = 'Ausschreibung...';
$sMenuScheme = 'Ziffernschemen';
$sMenuSchedule = 'Rahmenterminplan';
$sMenuLeagueOverview = 'Rundeneinteilung';
$sMenuHeadSecurity = 'Programmverwaltung...';
$sMenuSecMember = 'Benutzer';
$sMenuSecGroup = 'Benutzergruppen';
$sMenuSecMethod = 'Funktionen';
$sMenuPhpinfo = 'PHP Info';
$sMenuConfig1 = 'Konfiguration';
$sMenuConfig2 = 'Nachrichten';
$sMenuChangelog = 'Vereinsdaten Änderungen';
$sMenuRptClub = 'Reports Vereine';
$sMenuRptPlan = 'Reports Planung';
$sMenuRptLeague = 'Reports Runden';
$sMenuRptExport = 'Export';
$sMenuHeadExport = 'Listen...';
$sMenuAdrList = 'Addressen';
$sMenuLeagueLists = 'Runden-Spielpläne';
$sMenuClubLists = 'Vereins-Spielpläne';
$sMenuHeadActions = 'Prozesse...';
$sMenuActReport = 'Listen';
$sMenuActSeason = 'Saison';
$sMenuActMaintain = 'Wartung';
$sMenuActImport = 'Importe';
$sMenuRegion = 'Bezirk wechseln';
$sMenuRefereesPlanning = 'Schiedsrichtereinsätzen';
?>
