<?php
define("BROWSER_TITLE","clubs teams");

$PAGER_TITLE="Mannschaften von Verein:";
$ADD_TITLE="Mannschaft hinzufügen, Verein:";
$DELETE_TITLE="Mannschaft löschen, Verein:";
$VIEW_TITLE="Mannschaftsdaten anzeigen, Verein:";
$EDIT_TITLE="Mannschaftsdaten ändern, Verein:";
$sSelectNo="Ziffernwahl";



define("CLUB_ID_HEADING","id");
define("CLUB_ID_REMARK","Bezirk: Verein auswählen / über-LV: leer lassen");
define("SHORTNAME_HEADING","Verein");
define("TEAM_NO_HEADING","Mannschaft");
define("TEAM_NO_REMARK","Bezirk: Mannschaftsnr. / über-LV: Mannschaft+Nr");
define("TEAM_CHAR_HEADING","Ziffer");

define("LEAGUE_CHAR_HEADING","Ziffer");
define("LEAGUE_ID_HEADING","Runde");
define("LEAGUE_NAME_HEADING","Runde");

define("TRAINING_DAY_HEADING","Training Tag");
define("TRAINING_TIME_HEADING","Training Zeit");
define("TRAINING_TIME_REMARK","Zeit (hh:mm). Bitte nur volle Viertelstunden (:00, :15, :30 oder :45) angeben.");
define("PREF_GAME_DAY_HEADING","Bevorz. Spieltag");
define("PREF_GAME_TIME_HEADING","Bevorz. Spielzeit");
define("PREF_GAME_TIME_REMARK","Zeit (hh:mm). Bitte nur volle Viertelstunden (:00, :15, :30 oder :45) angeben.");
define("COLOR_HEADING","Trikotfarbe");
define("LASTNAME_HEADING","Verantwortlicher");
define("PHONE1_HEADING","Tel. (p)");
define("PHONE2_HEADING","Tel. (d)");
define("EMAIL_HEADING","E-Mail");
define("LEAGUE_PREV_HEADING","Runde Vorjahr");

?>