<?php
define("BROWSER_TITLE","Spiele");
define("PAGE_TITLE","Spiele Verwalten");


define("GAME_ID_HEADING","id");
define("LEAGUE_ID_HEADING","Liga");
define("GAME_DATE_HEADING","Spieltag");
define("GAME_TIME_HEADING","Zeit");
define("GAME_TEAM_HOME_HEADING","Heim");
define("GAME_TEAM_GUEST_HEADING","Gast");
define("GAME_NO_HEADING","Nr.");
define("GAME_TEAM_REF1_HEADING","Schiri");
define("GAME_TEAM_REF2_HEADING","2.Schiri");
define("GAME_GYM_HEADING","Halle");
?>