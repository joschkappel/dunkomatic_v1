<?php
define("PAGE_TITLE", BROWSER_TITLE." - Funktionen");

define("METHOD_ID_HEADING","id");
define("METHOD_NAME_HEADING","Operation");
define("CLASS_NAME_HEADING","Klasse");

?>