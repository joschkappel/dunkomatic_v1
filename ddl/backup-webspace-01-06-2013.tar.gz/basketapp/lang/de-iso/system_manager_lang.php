<?php
define("BROWSER_TITLE","Benutzer verwalten");
define("PAGE_TITLE","Benutzer");

define("SYSTEM_MANAGER_ID_HEADING","id");
define("SYSTEM_MANAGER_NAME_HEADING","Name");
define("USERNAME_HEADING","Benutzer");
define("PASSWORD_HEADING","Passwort");
define("RE_PASSWORD_HEADING","Passwort bestätigen");
define("SECURITY_GROUP_ID_HEADING","Benutzergruppe");
define("CLUB_ID_HEADING","Verein");
define("LEAGUE_ID_HEADING","Runde");
define("EMAIL_HEADING","eMail");

define("SEND_PASSWORD","Passwort senden");

?>