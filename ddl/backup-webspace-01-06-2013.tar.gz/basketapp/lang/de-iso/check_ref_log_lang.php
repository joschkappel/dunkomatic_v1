<?php
define("PAGE_TITLE",  BROWSER_TIILE." - Prüfung der Schiedsrichteransetzung");


define("CRL_ID_HEADING","ID");

define("CHECK_TYPE_HEADING","Fehlerart");
define("HOME_TEAM_HEADING","Heim");
define("GUEST_TEAM_HEADING","Gast");
define("GAME_NO_HEADING","Spiel Nr.");
define("GAME_DATE_HEADING","Datum");
define("LEAGUE_HEADING","Runde");
define("REF1_HEADING","Schiri 1");
define("REF2_HEADING","Schiri 2");

?>