<?php
define("PAGE_TITLE", BROWSER_TITLE." - Rahmenterminplan");


define("SCHEDULE_ID_HEADING","Nr.");

define("GAME_DATE_HEADING","Datum (Samstag)");

define("GAME_DAY_HEADING","Spieltag");

define("GROUP_ID_HEADING","Gruppe");

?>