<?php
define("BROWSER_TITLE","Datenexport");
define("PAGE_TITLE","Datenexport");


define("ACTION_ID_HEADING","id");
define("ACTION_DESC_HEADING","Aktion");
define("ACTION_CMD_HEADING","Ausführen");
define("LASTRUN_HEADING","Letzter Aufruf am");
define("LASTUSER_HEADING","von");
$ACTION_RESULT="ERLEDIGT";
$season_pokal="Jugendpokalrunde";
$season_champion="Meisterschaftsrunden";
?>