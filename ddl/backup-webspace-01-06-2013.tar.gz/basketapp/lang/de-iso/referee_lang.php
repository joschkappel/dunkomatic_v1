<?php
define("BROWSER_TITLE","Schiedsrichter verwalten");
define("PAGE_TITLE","Vereine - Schiedsrichter");

define("REF_ID_HEADING","id");
define("CLUB_ID_HEADING","Verein");
define("LASTNAME_HEADING","Nachname");
define("FIRSTNAME_HEADING","Vorname");
define("GENDER_HEADING","m/w");
define("BIRTHDATE_HEADING","geb.");
define("BIRTHDATE_REMARK","Datumsformat 5.8.71");
define("LIC_NO_HEADING","Lizenz Nr.");
define("COMMENT_HEADING","Bemerkung");
define("LIC_TYPE_HEADING","Status");
define("LIC_TYPE_REMARK","SR oder E");
define("PLAYER_LEAGUE_HEADING","spielt in");
define("COACH_LEAGUE_HEADING","trainiert");
define("NO_GAMES_HEADING","Anz. Spiele letzte Saison");
define("REGION_HEADING","Bezirk");
define("ACTIVE_REMARK","aktiv in 08/09?");
define("RECERT_HEADING","Fortbildung?");
define("SQUAD_HEADING","Kader");
define("STREET_HEADING","Str.");
define("ZIP_HEADING","PLZ");
define("CITY_HEADING","Stadt");
define("PHONE1_HEADING","Tel.gesch");
define("PHONE2_HEADING","Tel.priv");
define("FAX1_HEADING","Fax gesch");
define("FAX2_HEADING","Fax priv");
define("MOBILE_HEADING","Mobil");
define("EMAIL_HEADING","eMail");


?>