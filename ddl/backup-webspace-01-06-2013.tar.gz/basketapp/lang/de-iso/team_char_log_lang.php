<?php
define("BROWSER_TITLE","team assignment changes");
define("PAGE_TITLE","log of team assignment changes");


define("TEAM_ID_HEADING","Mannschaft");

define("CHAR_BEFORE_HEADING","Alte Ziffer");
define("CHAR_AFTER_HEADING","Neue Ziffer");

?>