<?php
define("PAGE_TITLE", BROWSER_TITLE." - Benutzergruppen");

define("SECURITY_GROUP_ID_HEADING","id");
define("SECURITY_GROUP_NAME_HEADING","Gruppe");
define("SECURITY_LEVEL_HEADING","Berechtigungslevel (lesen/ändern)");
define("MENU_LEVEL_HEADING","Menulevel");

?>