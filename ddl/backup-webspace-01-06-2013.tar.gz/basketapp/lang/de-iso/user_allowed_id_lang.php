<?php
define("BROWSER_TITLE","Benutzer verwalten");
define("PAGE_TITLE","Benutzer");

define("UA_ID_HEADING","id");
define("SYSTEM_MANAGER_ID_HEADING","Name");
define("DBOBJ_NAME_HEADING","Objekt");
define("ALLOWED_ID_HEADING","id");

?>