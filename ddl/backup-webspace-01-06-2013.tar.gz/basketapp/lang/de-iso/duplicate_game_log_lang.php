<?php
define("PAGE_TITLE",  BROWSER_TIILE." - Überschneidende Spielansetzungen");


define("DGL_ID_HEADING","ID");

define("DUPLICATE_DATE_HEADING","Spieldatum");
define("HOME_TEAM_HEADING","Heim");
define("GUEST_TEAM_HEADING","Gast");
define("GYM_NO_HEADING","Halle");
define("GAME_COUNT_HEADING","Anzahl Spiele");
define("DUPLICATE_TYPE_HEADING","Art");
define("LASTUSER_HEADING","Test von");
define("LASTCHANGE_HEADING","am");

?>