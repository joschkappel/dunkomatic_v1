<?

define("PAGE_TITLE",BROWSER_TITLE." - Rechte");


define("PERMISSION_ID_HEADING","id");
define("SECURITY_GROUP_ID_HEADING","Gruppe");
define("CLASS_NAME_HEADING","Klasse");
define("METHOD_NAME_HEADING","Operation");

define("ALLOW_HEADING","Erlaubt");

?>