<?php
define("BROWSER_TITLE","Hallen verwalten");
define("PAGE_TITLE","Vereine - Hallen");

define("GYM_ID_HEADING","id");

define("NAME_HEADING","Hallenname");
define("NAME_REMARK","Hallenname in Langform (zB: \"Sporthalle der Goetheschule\")");

define("SHORTNAME_HEADING","Nr.");
define("SHORTNAME_REMARK","Laufende Nr. der Halle (1,2,3,...)");

define("ZIP_HEADING","PLZ");
define("CITY_HEADING","Stadt");
define("STREET_HEADING","Strasse");

$gymnasium_ids_array=array("1","2","3","4","5","6");
$gymnasium_values_array=array("1","2","3","4","5","6");

?>