<?php
define("BROWSER_TITLE","Rahmenterminpläne");

define("ID_HEADING","id");

define("GROUP_NAME_HEADING","Rahmenterminpläne");
define("GROUP_NAME_REMARK","Name des Rahmenplans");

?>