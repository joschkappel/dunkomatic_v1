<?php
define("BROWSER_TITLE","Nachrichten verwalten");
define("PAGE_TITLE","Nachrichten");

define("SETTINGS_ID_HEADING","id");
define("SETTING_NAME_HEADING","Parameter");
define("DESCRIPTION_HEADING","Beschreibung");
define("SETTING_VALUE_HEADING","Nachricht");
define("SETTING_COMMENT_HEADING","Kommentar");
define("SETTING_VAR_HEADING","Variable");
define("SETTING_VAR_REMARK","accessible as global variable");
?>