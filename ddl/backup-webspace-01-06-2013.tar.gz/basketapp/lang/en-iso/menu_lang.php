<?php

define("LOGOUT","exit");
define("ADMIN_HOME","home");
define("MAIN_MENU","menu");


/*
 * JK  language string table
 */
 
// Side Bar 
$sMenuHeadAdmin = 'Work on...';
$sMenuClubs = 'Clubs';
$sMenuMembers = 'Members';
$sMenuSeason = 'Season';
$sMenuLeagues = 'League';
$sMenuHeadConfig = 'Settings...';
$sMenuTeamChar = 'Letter Change Log';
$sMenuHeadSecurity = 'Security';
$sMenuSecMember = 'Users';
?>
