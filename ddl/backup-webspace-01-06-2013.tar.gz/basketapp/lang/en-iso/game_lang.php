<?php
define("BROWSER_TITLE","games");
define("PAGE_TITLE","admin games");


define("GAME_ID_HEADING","id");
define("LEAGUE_ID_HEADING","League");
define("GAME_DATE_HEADING","Date");
define("GAME_TIME_HEADING","Time");
define("GAME_TEAM_HOME_HEADING","Home");
define("GAME_TEAM_GUEST_HEADING","Guest");
define("GAME_NO_HEADING","No.");
define("GAME_TEAM_REF1_HEADING","Ref");
define("GAME_TEAM_REF2_HEADING","2nd Ref");
define("GAME_GYM_HEADING","Arena");
?>