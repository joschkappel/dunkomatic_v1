<?php
define("BROWSER_TITLE","Runden");
define("PAGE_TITLE","admin runden");


define("ID_HEADING","id");
define("SHORTNAME_REMARK","max 3 chars");

define("SHORTNAME_HEADING","Runde");

define("NAME_HEADING","Name");
?>