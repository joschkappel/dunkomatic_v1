<?php
define("BROWSER_TITLE","clubs teams");
define("PAGE_TITLE","admin clubs teams");


define("CLUB_ID_HEADING","id");
define("LEAGUE_CHAR_HEADING","Buchstabe");
define("SHORTNAME_HEADING","Verein");

define("LEAGUE_ID_HEADING","Liga id");
define("LEAGUE_NAME_HEADING","Liga");
define("LEAGUE_TEAMS_HEADING","Anzahl Teams");
?>