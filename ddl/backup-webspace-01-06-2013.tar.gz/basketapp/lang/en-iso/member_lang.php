<?php
define("BROWSER_TITLE","Administer Members");
define("PAGE_TITLE","Clubb - Members");

define("MEMBER_ID_HEADING","id");
define("MEMBER_ROLE_ID_HEADING","Role");
define("LASTNAME_HEADING","Lastname");
define("FIRSTNAME_HEADING","Firstname");
define("CITY_HEADING","City");
define("ZIP_HEADING","Zip");
define("STREET_HEADING","Street");
define("PHONE1_HEADING","Phone (private)");
define("PHONE2_HEADING","Phone (bus.)");
define("EMAIL_HEADING","E-Mail");
define("INSTMSG_HEADING","Skype");
define("MOBILE_HEADING","Phone (mobile)");


// member_roles see member.definition
define('LEAD', "Clubexec");
define('REF', "Referee-exec");
define('PRESS', "Marketing");
$member_role_ids_array=array("0","1","2");
$member_role_values_array=array(LEAD,REF,PRESS);


?>