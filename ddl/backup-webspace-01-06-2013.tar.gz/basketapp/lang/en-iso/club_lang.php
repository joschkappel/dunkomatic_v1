<?php
define("BROWSER_TITLE","Vereine verwalten");
define("PAGE_TITLE","Verein ");


define("ID_HEADING","id");

define("SHORTNAME_HEADING","Verein");
define("SHORTNAME_REMARK","max 4 chars");

define("NAME_HEADING","Name");

define("CLUB_NO_HEADING","No.");

define("CLUB_URL_HEADING","URL");

?>