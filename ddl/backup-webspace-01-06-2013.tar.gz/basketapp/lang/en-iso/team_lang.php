<?php
define("BROWSER_TITLE","clubs teams");
define("PAGE_TITLE","admin clubs teams");


define("CLUB_ID_HEADING","id");
define("SHORTNAME_HEADING","Verein");
define("TEAM_NO_HEADING","Mannschaft");

define("LEAGUE_CHAR_HEADING","Buchstabe");
define("LEAGUE_ID_HEADING","Liga");
define("LEAGUE_NAME_HEADING","Liga");
?>