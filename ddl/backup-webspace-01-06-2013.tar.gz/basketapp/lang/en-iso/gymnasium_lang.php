<?php
define("BROWSER_TITLE","Maintain Gymnasiums");
define("PAGE_TITLE","Clubs - Gymnasiums");

define("GYM_ID_HEADING","id");

define("NAME1_HEADING","Gymnasium");
define("NAME2_HEADING","Name 2");

?>