<?php
/*
 * Created on 28/02/2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
$size_limit = "yes"; //do you want a size limit yes or no.
$limit_size = "500000"; //How big do you want size limit to be in bytes
$limit_ext = "yes"; //do you want to limit the extensions of files uploaded
$ext_count = "1"; //total number of extensions in array below
$extensions = array(".xls"); //List extensions you want files uploaded to be
 
?>
