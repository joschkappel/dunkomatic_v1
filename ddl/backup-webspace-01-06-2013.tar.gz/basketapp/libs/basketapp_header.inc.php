<?php
include_once($FW_ROOT."/config.php");
include_once($ROOT.'appconfig.php');
include_once($ROOT.'libs/common.lib.php');
include_once($FW_ROOT.'common/adodb/adodb.inc.php');
include_once($FW_ROOT.'objects/security_objects/security_handler.class.php');
include_once($FW_ROOT.'common/functions/general.php');

include_once($ROOT.'lang/'.$cfg ['DefaultLang'].'/app_lang.php');
include_once($ROOT.'lang/'.$cfg ['DefaultLang'].'/menu_lang.php');


?>