<?php
define('DOWNLOAD_DIR',$FW_ROOT.'config/'.$_SESSION['region'].'/downloads/');
define('UPLOAD_DIR',$FW_ROOT.'config/'.$_SESSION['region'].'/uploads/');
define('DDIR_CLUBS', DOWNLOAD_DIR.'Vereine');
define('DDIR_LEAGUES', DOWNLOAD_DIR.'Runden');
define('DDIR_LISTS', DOWNLOAD_DIR.'Adresslisten');
?>