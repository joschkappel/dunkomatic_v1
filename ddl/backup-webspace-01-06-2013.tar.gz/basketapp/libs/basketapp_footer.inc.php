<?php

include($FW_ROOT.'templates/basketapp_tpl/footer_tpl.php');

?>