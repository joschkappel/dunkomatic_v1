<?
$APLICATION_ROOT="../";
$FW_ROOT="../";
$ROOT="";
?>