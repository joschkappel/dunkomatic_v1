<?php
include_once('root.inc.php');
$obj_name="system_manager";
include_once($ROOT.'libs/basketapp_header.inc.php');
include($ROOT.'libs/basketapp_controller.inc.php');

include($ROOT.'pages/selectregion.php');

include_once($ROOT.'libs/basketapp_footer.inc.php');

?>