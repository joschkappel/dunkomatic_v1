<?php
/*
 * Created on May 17, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
include_once('root.inc.php');

//ini_set( "include_path", ( "/home/josch/workspace/Dunkomatic/common/pear/PEAR" .":" .ini_get("include_path"))); 
ini_set( "include_path", ( "/var/www/html/web873/html/dunkomatic/common/pear/PEAR" .":" .ini_get("include_path")));
require_once "Spreadsheet/Excel/Writer.php";

// Create workbook
$xls =& new Spreadsheet_Excel_Writer('../../../config/HBVDA/phpPetstore.xls');
// Send the Spreadsheet to the browser
//$xls->send("phpPetstore.xls");

// Create worksheet
$cart =& $xls->addWorksheet('phpPetstore');

# Add the title
// Some text to use as a title for the worksheet
$titleText = 'phpPetstore: Receipt from ' . date('dS M Y');

// Create a format object
$titleFormat =& $xls->addFormat();

// Set the font family - Helvetica works for OpenOffice calc too...
$titleFormat->setFontFamily('Helvetica');

// Set the text to bold
$titleFormat->setBold();

// Set the text size
$titleFormat->setSize('13');

// Set the text color
$titleFormat->setColor('navy');

// Set the bottom border width to "thick"
$titleFormat->setBottom(2);

// Set the color of the bottom border
$titleFormat->setBottomColor('navy');

// Set the alignment to the special merge value
$titleFormat->setAlign('merge');

// Add the title to the top left cell of the worksheet,
// passing it the title string and the format object
$cart->write(0,0,$titleText,$titleFormat);

// Add three empty cells to merge with
$cart->write(0,1,'',$titleFormat);
$cart->write(0,2,'',$titleFormat);
$cart->write(0,3,'',$titleFormat);

// The the row height
$cart->setRow(0,30);

// Set the column width for the first 4 columns
$cart->setColumn(0,3,15);

# Add the column headings
// Set up some formatting
$colHeadingFormat =& $xls->addFormat();
$colHeadingFormat->setBold();
$colHeadingFormat->setFontFamily('Helvetica');
$colHeadingFormat->setSize('10');
$colHeadingFormat->setAlign('center');

// An array with the data for the column headings
$colNames = array('Item','Price($)','Quantity','Total');

// Add all the column headings with a single call
// leaving a blank row to look nicer
$cart->writeRow(2,0,$colNames,$colHeadingFormat);

// The cell group to freeze
// 1st Argument - vertical split position
// 2st Argument - horizontal split position (0 = no horizontal split)
// 3st Argument - topmost visible row below the vertical split
// 4th Argument - leftmost visible column after the horizontal split
$freeze = array(3,0,4,0);

// Freeze those cells!
$cart->freezePanes($freeze);

// Pseudo data
$items = array (
	array( 'description'=>'Parrot'	,'price'=>34.0,	'quantity'=>1),
	array( 'description'=>'Snake'	,'price'=>16.5,	'quantity'=>2),
	array( 'description'=>'Mouse'	,'price'=>1.25,	'quantity'=>10),
);

// Use this to keep track of the current row number
$currentRow = 4;

// Loop through the data, adding it to the sheet
foreach ( $items as $item ) {
    // Write each item to the sheet
	$cart->writeRow($currentRow,0,$item);
	
	// Remember Excel starts counting rows from #1!
	$excelRow = $currentRow + 1;
	
	// Create a PHP string containing the formula
	$formula = '=PRODUCT(B' . $excelRow . ':C' . $excelRow .')';
	
	// Add the formula to the row
	$cart->writeFormula($currentRow,3,$formula);
	
	$currentRow++;
}

// The first row as Excel knows it - $currentRow was 4 at the start
$startingExcelRow = 5;

// The final row as Excel
// (which is the same as the currentRow once the loop ends)
$finalExcelRow = $currentRow;

// Excel formal to sum all the item totals to get the grand total
$gTFormula = '=SUM(D'.$startingExcelRow.':D'.$finalExcelRow.')';

// Some more formatting for the grand total cells
$gTFormat =& $xls->addFormat();
$gTFormat->setFontFamily('Helvetica');
$gTFormat->setBold();
$gTFormat->setTop(1); // Top border
$gTFormat->setBottom(1); // Bottom border

// Add some text plus formatting
$cart->write($currentRow,2,'Grand Total:',$gTFormat);

// Add the grand total formula along with the format
$cart->writeFormula($currentRow,3,$gTFormula,$gTFormat);

$xls->close();
?>
