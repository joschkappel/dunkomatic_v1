<?php
include_once($FW_ROOT.'common/classes/form_classes/form_field.php');

$obj_name="schedule";
$id_column_name="schedule_id";

$fields_arr=array();


?>