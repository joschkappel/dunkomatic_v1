<?php
include_once('root.inc.php');
include_once('cronjob_header.inc.php');

ini_set( "include_path", ( "/home/jochen/workspace/Dunkomatic/common/reporting" .":" .ini_get("include_path")));
    
ini_set("memory_limit","512M"); 

include( $APLICATION_ROOT.'common/reporting/xlsgen.php' );
include( $APLICATION_ROOT.'common/reporting/dbxlsgen.php' );


if ($sSQLregion==''){
	$sWHEREregion = "";
} else {
	$sWHEREregion = " AND (l.region = '".$sSQLregion."' OR l.region='HBV') ";
}
	$myxls = new Db_SXlsGen();
	$myxls->filename = 'Adressen_Staffelleiter';
	$myxls->sheetname= 'Staffelleiter';
	$myxls->headerline[0]="Addressen aller Staffelleiter";
	$myxls->get_type = 1;
	$myxls->default_dir = DDIR_LISTS;
	$myxls->col_aliases = array("street"=>"Strasse","zip"=>"PLZ","city"=>"Ort","league_name"=>" ","shortname"=>"Runde","lastname"=>"Name","firstname"=>"Vorname","email"=>"eMail","phone1"=>"Tel.(p)","phone2"=>"Tel.(d)","mobile"=>"Mobil","fax1"=>"Fax","email2"=>"eMail 2");
	$myxls->fileFormat = array(0=>'CSV',1=>'PDF') ;
	$sql2 = 'SELECT l.shortname, l.league_name, m.lastname, m.firstname, m.street, m.zip, m.city, m.email, m.phone1, m.phone2, m.mobile, m.fax1, m.email2 FROM member as m, league as l WHERE m.member_role_id = 2 AND m.league_id=l.league_id '.$sWHEREregion.' ORDER BY l.shortname';

	$myxls->GetXlsFromQuery($sql2);
 
?>