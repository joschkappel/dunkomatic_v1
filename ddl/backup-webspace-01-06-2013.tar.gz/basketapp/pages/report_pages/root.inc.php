<?
$FW_ROOT="../../../";
$APLICATION_ROOT  = "../../../";
$ROOT="../../";
?>