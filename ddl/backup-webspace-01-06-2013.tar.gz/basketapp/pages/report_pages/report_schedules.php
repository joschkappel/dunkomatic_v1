<?php
include_once('root.inc.php');
$obj_name="schedule";
$page_title="Rahmenterminplan";
include_once($ROOT.'libs/basketapp_header.inc.php');
include_once($ROOT.'libs/basketapp_controller.inc.php');


// prepare data 
$sql2="SELECT sg.group_name, s.game_day, s.game_date, DATE_FORMAT(s.game_date,'%d.%m.%Y') as gamedate FROM `schedule` s, schedule_group sg WHERE s.group_id = sg.group_id ORDER BY 3, 1, 2";			
$rs2 = $conn->Execute($sql2);


while (!$rs2->EOF){
	$schedule[$rs2->fields['gamedate']][$rs2->fields['group_name']] = $rs2->fields['game_day'];
	$rs2->MoveNext();
}

?>
  <td valign="top" bgcolor="<?php echo $cfg['RightBgColor']; ?>">
   <table border="0" cellpadding="10" cellspacing="0">
    <tr>
     <td>

		<table border="2" frame="box" width="95%"><th>Datum</th>
<?php

$sql2="SELECT group_name FROM schedule_group sg ORDER BY 1";			
$rs2 = $conn->Execute($sql2);
$i=0;

while (!$rs2->EOF){
	$groups[$i] = $rs2->fields['group_name'];
	?>
	<th><?php echo $groups[$i] ?></th>
	<?php
	$i++;
	$rs2->MoveNext();
}

		
$dates = array_keys($schedule);

$i=0;
foreach ($dates as $date){
	$i++;
    $bgcolor          = ($i % 2) ? $cfg['BgcolorOne'] : $cfg['BgcolorTwo'];

	echo "<tr>";
	echo "<td bgcolor=\"".$bgcolor."\">".$date."</td>";
	
	foreach ($groups as $group){
		if ($schedule[$date][$group]!=''){
			echo "<td bgcolor=\"".$bgcolor."\" align=\"center\">".$schedule[$date][$group].".ST</td>";
		} else {
			echo "<td bgcolor=\"".$bgcolor."\" align=\"center\"> </td>";
		}
		
	}
	

	echo "</tr>";
}


?>
 </table>
  </td>
 </tr>
 </table>
 </td>
<?php 
include_once($ROOT.'libs/basketapp_footer.inc.php');
?>
