<?php
include ("rpt_vereinsspielplan.php");
include ("rpt_heimspielplan.php");
include ("rpt_schirispielplan.php");
?>