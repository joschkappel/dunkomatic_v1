<?php
include_once($APLICATION_ROOT.'common/classes/form_classes/form_field.php');
include_once($APLICATION_ROOT.'common/classes/form_classes/form_text_field.php');
include_once($APLICATION_ROOT.'common/classes/form_classes/form_hidden_field.php');

$obj_name="team_08_scheme";
$id_column_name="scheme_id";

$fields_arr=array();

$form_field1=new form_hidden_field("scheme_id");
$form_field1->set_is_primary_key(true);
$form_field1->set_show_in_list(true);
$form_field1->set_var_name("id");
$fields_arr["scheme_id"]=$form_field1;

$form_field2=new form_text_field("game_no");
$form_field2->set_show_in_list(true);
$fields_arr["game_no"]=$form_field2;

$form_field3=new form_text_field("game_day");
$form_field3->set_show_in_list(true);
$fields_arr["game_day"]=$form_field3;

$form_field4=new form_text_field("team_home");
$form_field4->set_show_in_list(true);
$fields_arr["team_home"]=$form_field4;

$form_field5=new form_text_field("team_guest");
$form_field5->set_show_in_list(true);
$fields_arr["team_guest"]=$form_field5;

?>
