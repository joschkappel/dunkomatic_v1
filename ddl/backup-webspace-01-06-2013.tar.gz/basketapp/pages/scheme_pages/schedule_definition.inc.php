<?php
include_once($FW_ROOT.'common/classes/form_classes/form_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_text_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_active_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_checkbox_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_hidden_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_selectboxdb_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_selectboxlist_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_url_field.php');
include_once($FW_ROOT.'common/classes/form_classes/form_datetime_field.php');


$obj_name="schedule";
$id_column_name="schedule_id";

$fields_arr=array();

$form_field1=new form_hidden_field("schedule_id");
$form_field1->set_is_primary_key(true);
$form_field1->set_show_in_list(true);
$form_field1->set_var_name("id");
$fields_arr["schedule_id"]=$form_field1;

$form_field5=new form_selectboxlist_field("group_id");
$form_field5->set_list_id_values($group_id_array);
$form_field5->set_list_display_values($group_id_values_array);
$form_field5->set_search_in_field(false);
$form_field5->set_show_in_list(true);
$fields_arr["group_id"]=$form_field5;

$form_field7=new form_text_field("game_day");
$form_field7->set_show_in_list(true);
$fields_arr["game_day"]=$form_field7;

$form_field8=new form_datetime_field("game_date");
$form_field8->set_date_type('DT_DATE');
$form_field8->set_date_format(DATE_FORMAT_SHORT);
$form_field8->set_show_in_list(true);
$fields_arr["game_date"]=$form_field8;

?>