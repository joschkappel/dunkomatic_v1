<?php
// include ThemeManager if available

if (isset($available_themes_choices) && $available_themes_choices > 1) {
    $theme_selected = FALSE;
?>
    <!-- Theme Manager -->
   
        
            <form name="setTheme" method="post" action="index.php" >
                <?php 
                echo (isset($strTheme) ? $strTheme : 'Theme (Style)');
                ?> 
                <select name="set_theme" onchange="this.form.submit();" style="vertical-align: middle">
                <?php
                    foreach ($available_themes_choices AS $cur_theme) {
                        echo '<option value="' . $cur_theme . '"';
                        if ($cur_theme == $theme) {
                            echo ' selected="selected"';
                        }
                        echo '>' . htmlspecialchars($available_themes_choices_names[$cur_theme]) . '</option>';
                    }
                ?>
                </select>
                <noscript><input type="submit" value="Go" style="vertical-align: middle" /></noscript>
            </form>
        
<?php
}
?>
       
