<?php
/* $Id: info.inc.php,v 1.1 2005/08/22 13:39:30 Jochen Exp $ */
/* Theme information */
$theme_name = 'Darkblue/orange';
$theme_version = 1;
$theme_generation = 1;
?>
