<?php
/* $Id: info.inc.php,v 1.1 2005/08/22 13:40:36 Jochen Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 1;
$theme_generation = 1;
?>
